USE ProyectoFinal;

INSERT INTO Cajeros (idCajero, idEmpleado, Sueldo)
VALUES (NEWID(), '41260eac-70dc-4a8d-af6a-3284c31cd852', ''), (NEWID(), 'af4a71a9-416e-4301-a3b0-58ae391746b3', ''),
(NEWID(), '12a8eb7d-fff3-4c83-ba18-6de31a2b8a27', ''), (NEWID(), 'ee16bfb4-c949-43b4-a6e0-6907fa8472be', ''),
(NEWID(), 'b32d139f-c23f-4e55-aa9c-98caf3704348', ''), (NEWID(), '0f0b4441-f099-4f91-8d97-6fcea758d1a6', ''),
(NEWID(), '39b88e33-5e34-43a8-a827-c6e765b79e51', ''), (NEWID(), '399d9b02-60f6-4820-b59c-bc3d4869560d', ''),
(NEWID(), 'eee3f1ab-2001-4e66-895b-f305f010e141', '')