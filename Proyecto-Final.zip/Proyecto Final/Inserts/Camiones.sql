USE ProyectoFinal;

INSERT INTO Camiones (idCamion, idAsientos, idChofer, Matricula)
VALUES (NEWID(), '0667826c-10a9-4197-98ca-3190bcd1c36c', '220cf9ea-91ce-4954-947d-16c62375e06e', '17854'),
(NEWID(), '0f50a550-7af6-483d-b1fd-4b0384bcd14a', '7c877b17-c494-4de5-818e-1c87ff9f72cc', '29681'),
(NEWID(), '2f0a7498-4afd-4cb9-9ef8-6887c3e61edb', '221cd0db-271d-424c-95f5-2e5ead1de6ac', '865196'),
(NEWID(), '8225be0d-a3b2-443c-afcc-6f0beae94e1b', 'cab13a0c-f0d7-463c-804e-6e51040e7cbc', '6853'),
(NEWID(), '6a5d4272-6aa8-414c-8648-8ba152c398c9', 'ad2abaaa-6d8c-40d4-b69c-87d91f779e00', '9652558'),
(NEWID(), 'f11b2be1-4afd-49f7-b436-a97beec0075e', '046d4891-ac55-4528-90e3-94e5cd63787a', '68453'),
(NEWID(), '5a354352-1a77-47d7-8679-aa1c60458876', 'f9b3defd-01f6-411a-8da0-a1485c8e51a6', '652334'),
(NEWID(), 'e8f19148-de46-446b-9c18-b141b747f643', '7ad07067-69f7-4845-904f-bd691f57eeaf', '685412'),
(NEWID(), '3fb38206-684e-4ae6-8cee-b827babb00e9', '8ffa8a1b-e4ee-42ce-83de-f1d6af15e6fa', '96529'),
(NEWID(), '8577944c-05dd-4845-99c5-d492c7d8fad4', '16b7a1bc-1f09-4315-aab8-f35e8b871486', '52562')