USE ProyectoFinal;

INSERT INTO Rutas (idRutas, Origen, Destino, Distancia)
VALUES (NEWID(), 'Centro, Monterrey, N.L.', 'Centro, M�rida, Yucatan', '2.200 km'),
(NEWID(), 'Durango, Durango', 'Centro, Monterrey, N.L.', '595 km'),
(NEWID(), 'Centro, Monterrey, N.L.', 'Baja California, Tijuana', '2.361 km'),
(NEWID(), 'Centro, Monterrey, N.L.', 'Valle Dorado, Manzanillo, Colima', '1.100 km'),
(NEWID(), 'Centro, Monterrey, N.L.', 'Acapulco, Guerrero', '1.282 km'),
(NEWID(), 'Acapulco, Guerrero', 'G�mez Far�as, Saltillo, Coah', '1.218 km'),
(NEWID(), 'Centro, Monterrey, N.L.', 'Jalpan de Serra, Quer�taro', '657 km'),
(NEWID(), 'Reynosa, Tamaulipas', 'Centro, Monterrey, N.L.', '220 km'),
(NEWID(), 'Centro, Monterrey, N.L.', 'Gral. Zaragoza, Tamaulipas', '422 km'),
(NEWID(), 'Centro, Monterrey, N.L.', 'P�tzcuaro, Michoac�n', '881 km')