USE ProyectoFinal;

INSERT INTO Ventas (idVentas, BoletosVendidos, Precio, idCajero)
VALUES (NEWID(), '18', '30', '207b99b5-d4e5-4f80-ac41-1e379661c833'), (NEWID(), '29', '50', 'd01fea8a-007e-4e73-ae23-8d702c4d1fc4'),
(NEWID(), '2', '40', '34c58ffc-0176-417c-a8d8-aa1a0e6ff166'), (NEWID(), '45', '20', '643fc6aa-6584-4718-999c-9b5c44ebad7a'),
(NEWID(), '8', '35', '42534fec-2bca-4313-9cdb-bace1fb9d529'), (NEWID(), '15', '50', 'cb6257fd-e927-4c18-992c-ad664c1eddbe'),
(NEWID(), '10', '20', '57a81516-dcbb-4270-9d3f-c489e4b7e368'), (NEWID(), '10', '20', 'ca950812-e30e-4ab1-ab69-c1ced42ba9db'),
(NEWID(), '8', '30', '0dc2e8b0-bd94-4a32-b542-d187bde605b3')