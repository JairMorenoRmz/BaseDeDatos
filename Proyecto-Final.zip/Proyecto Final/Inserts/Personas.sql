USE ProyectoFinal;

INSERT INTO Personas (idPersonas, Nombre, Apellidos, FechaNacimiento)
VALUES (NEWID(), 'Eduardo', 'Cueto Salazar', '05/04/1998'), (NEWID(), 'Carlos', 'Vald�s Soto', '04/30/1992'),
(NEWID(), 'Andrea Vanessa', 'Almar�z Pe�uela', '10/01/1956'), (NEWID(), 'Sof�a', 'Perez Gonzalez', '04/08/1995'),
(NEWID(), 'Jonathan', 'Escandon Montes', '05/17/1947'), (NEWID(), 'Tania Sofia', 'Rodriguez Garza', '06/25/1955'),
(NEWID(), 'Eduardo Osvaldo', 'Gonzalez Lino', '04/23/1996'), (NEWID(), 'Arely', 'Hernandez Jimenes', '04/05/1998'),
(NEWID(), 'Monica Leticia', 'Grimaldo Cazarez', '10/18/1978'), (NEWID(), 'Fabiola', 'Arreazola Ovalle', '11/13/1957')

INSERT INTO Personas (idPersonas, Nombre, Apellidos, FechaNacimiento)
VALUES (NEWID(), 'Erika', 'Mata Mata', '12/29/1998'), (NEWID(), 'Diana Valeria', 'Loera Gallegos', '05/18/1997'),
(NEWID(), 'Daniel', 'Gonzalez Cant�', '10/10/1994'), (NEWID(), 'Griselda', 'Orozco Beltr�n', '02/04/1996'),
(NEWID(), 'Diego', 'Castillo Casas', '10/15/1991'), (NEWID(), 'Alan Cesar', 'Martinez Rivera', '04/30/1993'),
(NEWID(), 'Miguel', 'Leal Lozano', '12/14/1986'), (NEWID(), 'Fernanda', 'Vazquez Cantu', '08/14/1981'),
(NEWID(), 'Jorge', 'Martinez Suarez', '06/07/2000'), (NEWID(), 'Cecilia', 'Prado Aguilar', '03/10/1975')

INSERT INTO Personas (idPersonas, Nombre, Apellidos, FechaNacimiento)
VALUES (NEWID(), 'Diego', 'Barraza Contreras', '04/11/1998'), (NEWID(), 'Gilberto', 'Solis Contreras', '02/18/2010'),
(NEWID(), 'Cesar Humberto', 'Trevi�o Garza', '04/01/1953'), (NEWID(), 'Sofia Alejandra', 'Moreo Chapa', '10/25/1968'),
(NEWID(), 'Jaime', 'Sanchez Lopez', '09/02/2008'), (NEWID(), 'Jos�', 'Alfredo Jimenez', '04/09/2001'),
(NEWID(), 'Arturo', 'Arredondo Trevi�o', '04/27/1980'), (NEWID(), 'Riardo', 'Trevi�o Chapa', '03/29/1945'),
(NEWID(), 'Jorge', 'Vazquez Leal', '07/22/2005'), (NEWID(), 'Jos�', 'Madero Vizca�no', '02/09/1989')