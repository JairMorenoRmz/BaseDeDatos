USE ProyectoFinal;

INSERT INTO Clientes (idClientes, idPersona, Tipo)
VALUES (NEWID(), '8e92483e-f1a6-467c-a762-fc1e50914a8f', 'Estudiante'), (NEWID(), '03a158a0-aa69-4197-a5cb-f1091145afad', 'Estudiante'),
(NEWID(), 'd52119b3-8a14-43f3-80e8-ec327ae41a60', 'Cliente Frecuente'), (NEWID(), '58f99dd2-8712-492b-ac04-e26fa0cd9677', 'Tercera Edad'),
(NEWID(), 'd5728772-fe0a-49c8-a753-e052c5404f48', 'Tercera Edad'), (NEWID(), '6d1b00e5-e027-4878-a04c-d8d5c140beb2', 'Estudiante'),
(NEWID(), '41446545-eb6d-428c-86e2-d645ea124658', 'Estudiante'), (NEWID(), 'ad1c2967-5395-4040-bf35-67ffcd5550d2', 'Cliente Frecuente'),
(NEWID(), 'ef7f5090-6ae5-4e63-bda6-500dd9e9f569', 'Tercera Edad'), (NEWID(), '04b0ee0d-ef0e-4b03-984d-23e3d578f967', 'Estudiante')