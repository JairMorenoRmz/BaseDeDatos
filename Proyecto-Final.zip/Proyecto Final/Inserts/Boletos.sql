USE ProyectoFinal;

INSERT INTO Boletos (idBoletos, idCliente, idViajes, idCompra)
VALUES (NEWID(), 'a74883a1-f9e0-4218-b35c-0579a3b47428', '616fb972-b4fa-4c5e-b6b4-032d22981f29', '4c0d086f-3146-4f6b-ba91-12c7cc6df186'),
(NEWID(), 'f1836095-38d2-4f6b-8fc0-05ee9cd6e363', 'cd3c4a29-38e6-476a-af4d-3e0c1a5dadc6', '34807855-89ab-4fc1-b71d-63b153f9b68f'),
(NEWID(), 'ad9a5744-b5fd-45ae-9eca-2ef7914744ee', '5a61d568-9578-4a88-af79-4a71aea863e3', 'd12fcac9-0f63-4a6f-8fc5-7ac1adc4a40c'),
(NEWID(), 'dbb3a412-5752-415a-a540-432df898c94d', '66462a51-98cb-47e3-b458-63b128a2fb4a', '7aea0c92-1234-44e4-a55e-9ed22ea7daa5'),
(NEWID(), '6322de15-377a-4819-b58e-51c8bf23282a', '70852e66-bc3e-4b2f-b459-b6a996332dca', '43eed34c-c3df-4fca-b316-a33ad637fd8a'),
(NEWID(), 'cf224416-c1dd-41e9-853b-722369acb629', '346f3a00-1883-4e7e-afe6-bf78c1a04db9', '95b9f31b-7204-4d6c-a458-ae260ff8ddda'),
(NEWID(), 'd8f318f1-2675-4953-b672-b2957ba0ce05', '8323f640-947b-4bb8-8a46-c6b53bd565b8', '4bda892b-f434-4c99-9bd6-b372c6b61e57'),
(NEWID(), 'b551266d-5316-4df1-a062-bdfa8ed0990a', 'd123489a-bbfe-480a-a4e5-d20dde367112', 'b7588b86-3811-4e41-b11a-ebcc5df5bf3f'),
(NEWID(), 'c01e7fb3-61bd-42dc-aeb2-c8aabd868b34', '9d3ec23b-e21c-4689-abbe-dd3d7532213d', '9b02edf6-15ef-4f85-adc8-fb73c327e633')